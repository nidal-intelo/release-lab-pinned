"""qb -- stand-in for query-builder."""

from importlib.metadata import version

ROUNDING = "rounds DOWN"

CART_NOTE = "empty carts handled correctly"

TRACE = "query trace marker: enabled"


def describe() -> str:
    return f"qb {version('qb')}: {ROUNDING} ({CART_NOTE})"

# demo: tweak qb behavior
